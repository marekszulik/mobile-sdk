//
//  SPUserSpec.m
//  SponsorPaySDK
//
//  Created by Piotr  on 18/07/14.
//  Copyright 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>
#import "SPUser.h"
#import <CoreLocation/CoreLocation.h>

SpecBegin(SPUser)

/*
 Following is the tests case for basic data:
 1. Initialized SPUser object with basic data
 2. Validated the data type is correct
 3. Validated the data can be individually removed
 4. Checked reset functionality
 5. Cleanup
 */

describe(@"SPUser basic data", ^{

    __block SPUser *user;
    __block NSDate *dob;

    beforeEach(^{
        // Initialize user
        user = [[SPUser alloc] init];
        dob  = [NSDate date];
        CLLocation *location = [[CLLocation alloc] initWithLatitude:10.0 longitude:20.0];

        // Set some parameters
        [user setAge:25];
        [user setBirthdate:dob];
        [user setGender:SPUserGenderFemale];
        [user setEthnicity:SPUserEthnicityIndian];
        [user setEducation:SPUserEducationHighSchool];
        [user setMaritalStatus:SPUserMartialStatusMarried];
        [user setSexualOrientation:SPUserSexualOrientationStraight];
        [user setLocation:location];
        [user setNumberOfChildren:2];
        [user setInterests:@[@"football", @"travelling"]];

    });

    it(@"Validate data type is correct", ^{
        //

        // Age
        expect([user age]).to.equal(25);

        // Date of birth data type
        expect([user birthdate]).to.beKindOf([NSDate class]);

        // Date of birth - The date time is discarded, so it represents the earliest possible time od the date
        expect([[user birthdate] earlierDate:dob]).to.beTruthy;

        // Gender
        expect([user gender]).to.equal(SPUserGenderFemale);

        // Ethnicity
        expect([user ethnicity]).to.equal(SPUserEthnicityIndian);

        // Education
        expect([user education]).to.equal(SPUserEducationHighSchool);

        // Martial status
        expect([user maritalStatus]).to.equal(SPUserMartialStatusMarried);

        // Number of children
        expect([user numberOfChildren]).to.equal(2);

        // Sexual orientation
        expect([user sexualOrientation]).to.equal(SPUserSexualOrientationStraight);

        // Check the data type of `location`
        CLLocation *location = [user location];
        expect(location.coordinate.latitude).to.equal(10.0);
        expect(location.coordinate.longitude).to.equal(20.0);


        // Check the data type of `interests`
        id interests = [user interests];
        expect(interests).to.beKindOf([NSArray class]);
        
        // Check the `interests` is not empty
        expect([interests count]).notTo.beLessThan(1);

    });

    /*
     Location
     1. Check device location is enabled
     2. Validate current location when overwritten location has been provided
     3. Validate current location from device location
     */

    it(@"SPUser location", ^{
        if([CLLocationManager locationServicesEnabled]) {
            // If device location is enabled
            // Validate coordinates are overwritten
            CLLocation *location = [user location];
            expect(location.coordinate.latitude).to.equal(10.0);
            expect(location.coordinate.longitude).to.equal(20.0);

            // Remove location
            [user setLocation:nil];

            // Validate coordinates comes from current location - they should not be nil
            CLLocation *currentLocation = [user location];
            expect(currentLocation).notTo.beNil;

            // Expect location not to hold original values
            expect(currentLocation.coordinate.latitude).to.equal(10.0);
            expect(currentLocation.coordinate.longitude).to.equal(20.0);

            // Expect location to hold value
            expect(currentLocation.coordinate.latitude).notTo.equal(0);
            expect(currentLocation.coordinate.longitude).notTo.equal(0);
        } else {
            // If device location is disabled
            // Validate coordinates are setu up
            CLLocation *location = [user location];
            expect(location.coordinate.latitude).to.equal(10.0);
            expect(location.coordinate.longitude).to.equal(20.0);

            // Remove location
            [user setLocation:nil];

            // Validate current location is nil
            CLLocation *currentLocation = [user location];
            expect(currentLocation).to.beNil;
        }
    });

    it(@"Validate basic data is removed", ^{
        NSInteger count = [[user data] count];

        // Validate gender is removed
        [user setGender:SPUserGenderUndefined];
        expect([user gender]).to.equal(SPUserGenderUndefined);
        count --;

        // Validate ethnicity is removed
        [user setEthnicity:SPUserEthnicityUndefined];
        expect([user ethnicity]).to.equal(SPUserEthnicityUndefined);
        count --;

        // Validate education is removed
        [user setEducation:SPUserEducationUndefined];
        expect([user education]).to.equal(SPUserEducationUndefined);
        count --;

        // Validate martial status is removed
        [user setMaritalStatus:SPUserMaritalStatusUndefined];
        expect([user maritalStatus]).to.equal(SPUserMaritalStatusUndefined);
        count --;

        // Validate sexual orientation is removed
        [user setSexualOrientation:SPUserSexualOrientationUndefined];
        expect([user sexualOrientation]).to.equal(SPUserSexualOrientationUndefined);
        count --;

        // Validate location is removed
        [user setLocation:nil];
        count --;

        // Validate total amount of objects after removal
        expect([[user data] count]).to.equal(count);
    });

    it(@"Validate user data has been cleared", ^{
        // Validate user cleared values
        [user reset];
        expect([user data]).to.beNil;
    });

    afterEach(^{
        dob = nil;
        user = nil;
    });

});

/*
 Following is the tests case for extra data:
 1. Initialized SPUser object with extra data
 2. Validated the data type is correct
 3. Clean up
 */

describe(@"SPUser extra data", ^{
    __block SPUser *user;
    __block NSTimeInterval now;

    beforeAll(^{
        // Initialize user
        user = [[SPUser alloc] init];
        now = [[NSDate date] timeIntervalSince1970];

        // Set some parameters
        [user setIap:YES];
        [user setIapAmount:15.25];
        [user setNumberOfSessions:10];
        [user setPsTime:now];
        [user setLastSession:now];
        [user setConnectionType:SPUserConnectionTypeWiFi];
        [user setDevice:SPUserDeviceIPad];
        [user setVersion:@"3"];
    });

    it(@"Validate return data type and its values is correct", ^{
        // iap
        expect([user iap]).to.beTruthy();

        // iap amount
        expect([user iapAmount]).to.equal(15.25);

        // number of sessions
        expect([user numberOfSessions]).to.equal(10);

        // ps time
        expect([user psTime]).to.equal(now);

        // last sessions
        expect([user lastSession]).to.equal(now);

        // connection type
        expect([user connectionType]).to.equal(SPUserConnectionTypeWiFi);

        // device
        expect([user device]).to.equal(SPUserDeviceIPad);

        // version data type
        expect([user version]).to.beKindOf([NSString class]);

        // version
        expect([user version]).to.equal(@"3");
    });
    
    afterAll(^{
        user = nil;
        now = 0;
    });
});

SpecEnd
