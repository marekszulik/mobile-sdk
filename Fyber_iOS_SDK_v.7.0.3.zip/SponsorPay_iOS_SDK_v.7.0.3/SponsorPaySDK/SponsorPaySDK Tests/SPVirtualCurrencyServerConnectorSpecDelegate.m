//
//  SPVirtualCurrencyServerConnectorSpecDelegate.m
//  SponsorPaySDK
//
//  Created by Daniel Barden on 18/09/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPVirtualCurrencyServerConnectorSpecDelegate.h"


@interface SPVirtualCurrencyServerConnectorSpecDelegate()

@property (nonatomic, strong, readwrite) SPVirtualCurrencyServerConnector *vcs;
@property (nonatomic, assign, readwrite) NSInteger deltaOfCoins;
@property (nonatomic, copy, readwrite) NSString *currencyName;

@property (nonatomic, assign, readwrite) SPVirtualCurrencyRequestErrorType errorType;
@property (nonatomic, strong, readwrite) NSString *errorCode;
@property (nonatomic, strong, readwrite) NSString *errorMessage;

@end


@implementation SPVirtualCurrencyServerConnectorSpecDelegate

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)connector
  didReceiveDeltaOfCoinsResponse:(double)deltaOfCoins
                    currencyName:(NSString *)currencyName
             latestTransactionId:(NSString *)transactionId
{
    self.vcs = connector;
    self.deltaOfCoins = deltaOfCoins;
    self.currencyName = currencyName;
}

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)connector
                 failedWithError:(SPVirtualCurrencyRequestErrorType)error
                       errorCode:(NSString *)errorCode
                    errorMessage:(NSString *)errorMessage
{
    self.vcs = connector;
    self.errorType = error;
    self.errorCode = errorCode;
    self.errorMessage = errorMessage;
}

@end
