//
//  SPBaseNetworkSpec.m
//  SponsorPaySDK
//
//  Created by Daniel Barden on 17/04/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>

#import "SPBaseNetwork.h"

SpecBegin(SPBaseNetwork)

describe (@"SPBaseNetwork", ^{
    __block SPBaseNetwork *sut;

    beforeEach(^{
        sut = [[SPBaseNetwork alloc] init];
    });

    it(@"should raise an exception when calling adapterVersion", ^{
        expect(^{
            [SPBaseNetwork adapterVersion];
        }).to.raise(NSInternalInconsistencyException);
    });

    it(@"should raise an exception when calling startSDK", ^{
        expect(^{
            [sut startSDK:nil];
        }).to.raise(NSInternalInconsistencyException);
    });
});

SpecEnd
