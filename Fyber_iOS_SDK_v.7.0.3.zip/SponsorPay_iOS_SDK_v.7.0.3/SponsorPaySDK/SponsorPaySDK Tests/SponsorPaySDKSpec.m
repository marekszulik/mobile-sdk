//
//  SponsorPaySDKSpec.m
//  SponsorPaySDK
//
//  Created by Daniel Barden on 17/04/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>

#import "SponsorPaySDK.h"
#import "SPConstants.h"

SpecBegin(SponsorPaySDK)

describe(@"SponsorPaySDK", ^{

    it(@"should return credentials when initialized", ^{
        NSString *credentials = [SponsorPaySDK startForAppId:@"8058" userId:@"test" securityToken:nil];
        expect(credentials).toNot.beNil();
    });

    it(@"should throw an exception when userId is nil", ^{
        expect(^{
            [SponsorPaySDK startForAppId:@"8058" userId:nil securityToken:nil];
        }).to.raise(SPInvalidUserIdException);
    });

    it(@"should return false when credentials do not exist", ^{
        BOOL isCredentialValid = [SponsorPaySDK isCredentialsTokenValid:@"test"];
        expect(isCredentialValid).to.beFalsy();
    });

    it(@"should return true when credentials do exist", ^{
        NSString *credentialsToken = [SponsorPaySDK startForAppId:@"8058" userId:@"test" securityToken:nil];
        BOOL isCredentialValid = [SponsorPaySDK isCredentialsTokenValid:credentialsToken];
        expect(isCredentialValid).to.beTruthy();
    });

});

SpecEnd
