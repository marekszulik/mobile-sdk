//
//  SPInterstitialClientSpec.m
//  SponsorPaySDK
//
//  Created by Daniel Barden on 04/03/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//
 
#define EXP_SHORTHAND
#import <Specta/Specta.h>
#import <Expecta/Expecta.h>
#import <OHHTTPStubs/OHHTTPStubs.h>
#import <OHHTTPStubs/OHHTTPStubsResponse+JSON.h>

#import "SPInterstitialClient.h"
#import "SPInterstitialClient_SDKPrivate.h"
#import "SPInterstitialEvent.h"
#import "SPConstants.h"
#import "SPCredentials.h"
#import "SponsorPaySDK.h"

static NSString *const NotIntegratedNetworkName = @"NotIntegratedNetwork";
static NSString *const NotIntegratedAdId = @"1";

@interface SPInterstitialClient ()

- (NSURLRequest *)URLRequestForOffers;

@end

SpecBegin(SPInterstitialClient)

// This test uses SPCredentialsManager
// see SPCredentialsManagerSpec for more explanation

describe(@"SPInterstitialClient checkInterstitialAvailable", ^{
    __block SPInterstitialClient *sut;


    beforeAll(^{
        NSDictionary *notIntegratedDict = @{@"ads": @[@{@"provider_type": NotIntegratedNetworkName, @"ad_id": NotIntegratedAdId}]};

        /******************************************
        * Stubs all the requests to /interstitial *
        *******************************************/
        [OHHTTPStubs stubRequestsPassingTest:^BOOL(NSURLRequest *request) {
            return ([request.URL.host isEqualToString:@"engine.sponsorpay.com"] && [request.URL.path isEqualToString:@"/interstitial"]);
        } withStubResponse:^OHHTTPStubsResponse *(NSURLRequest *request) {
            if ([sut.credentials.appId isEqualToString:@"8058"]) {
                return [OHHTTPStubsResponse responseWithJSONObject:notIntegratedDict statusCode:200 headers:nil];
            } else {
                NSData* stubData = [@"OK" dataUsingEncoding:NSUTF8StringEncoding];
                return [OHHTTPStubsResponse responseWithData:stubData statusCode:200 headers:nil];
            }
        }];

        /**************************************
         * Stubs all the requests to /tracker *
         *************************************/
        [OHHTTPStubs stubRequestsPassingTest:^BOOL(NSURLRequest *request) {
            return ([request.URL.host isEqualToString:@"engine.sponsorpay.com"] && [request.URL.path isEqualToString:@"/tracker"]);
        } withStubResponse:^OHHTTPStubsResponse *(NSURLRequest *request) {
            NSData* stubData = [@"OK" dataUsingEncoding:NSUTF8StringEncoding];
            return [OHHTTPStubsResponse responseWithData:stubData statusCode:200 headers:nil];
        }];
    });

    beforeEach(^{
        sut = [[SPInterstitialClient alloc] init];
    });

    afterAll(^{
        [OHHTTPStubs removeAllStubs];
    });

    afterEach(^{
        [[NSNotificationCenter defaultCenter] removeObserver:self];
    });

    it(@"should send a no_sdk and no_fill events when 3rd party SDK is not integrated", ^AsyncBlock{
        
        SPCredentials *credentials = [SPCredentials credentialsWithAppId:@"8058"
                                                                  userId:@"someRandomId"
                                                           securityToken:nil];
        [sut setCredentials:credentials];
        
        __block BOOL noSdkHasBeenFired = NO;

        // SPInterstitial will fire two notifications when the SDK is not integrated - first the no_sdk and then the global no_fill.
        // Using noSdkHasBeenFired ensures the order in which they should be received
        [[NSNotificationCenter defaultCenter] addObserverForName:SPInterstitialEventNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
            SPInterstitialEvent *event = note.object;
            if (noSdkHasBeenFired) {
                expect(event.type).to.equal(SPInterstitialEventTypeNoFill);
                expect(event.adId).to.beNil();
                expect(event.network).to.beNil();
                done();
            }

            if (event.type == SPInterstitialEventTypeNoSDK) {
                noSdkHasBeenFired = YES;
                expect(event.adId).to.equal(NotIntegratedAdId);
                expect(event.network).to.equal(NotIntegratedNetworkName);
            }
        }];

        [sut checkInterstitialAvailable];
    });

    it(@"should set the placementId of the client when using the +[SponsorPaySDK checkInterstitialAvailable] method", ^{
        NSString *placementId = @"";
        [SponsorPaySDK startForAppId:@"8058"
                              userId:@"someRandomId"
                       securityToken:nil];

        [SponsorPaySDK checkInterstitialAvailable:nil];
        expect([SponsorPaySDK interstitialClient].placementId).to.equal(placementId);
    });

    it(@"should set the placementId of the client to @\"\" when using the +[SponsorPaySDK checkInterstitialAvailable:placementId] method", ^{
        NSString *placementId = @"PLACEMENT_ID";
        [SponsorPaySDK startForAppId:@"8058"
                              userId:@"someRandomId"
                       securityToken:nil];

        [SponsorPaySDK checkInterstitialAvailable:nil placementId:placementId];
        expect([SponsorPaySDK interstitialClient].placementId).to.equal(placementId);
    });

    it(@"should set the placementId of the client when using the -checkInterstitialAvailableForPlacementId method", ^{
        NSString *placementId = @"PLACEMENT_ID";
        SPCredentials *credentials = [SPCredentials credentialsWithAppId:@"8058"
                                                                  userId:@"someRandomId"
                                                           securityToken:nil];
        [sut setCredentials:credentials];
        [sut checkInterstitialAvailableForPlacementId:placementId];
        expect(sut.placementId).to.equal(placementId);
    });

    it(@"should set the placementId of the client to @\"\" when using the -checkInterstitialAvailable method", ^{
        NSString *placementId = @"";
        SPCredentials *credentials = [SPCredentials credentialsWithAppId:@"8058"
                                                                  userId:@"someRandomId"
                                                           securityToken:nil];
        [sut setCredentials:credentials];
        [sut checkInterstitialAvailable];
        expect(sut.placementId).to.equal(placementId);
    });

    it(@"the placement_id request param should be an empty string if not provided by the publisher", ^{
        NSString *placementId = nil;
        sut.placementId = placementId;

        NSURLRequest *URLRequest = [sut URLRequestForOffers];
        NSString *query = [URLRequest.URL query];
        NSString *param = [NSString stringWithFormat:@"placement_id=%@", @""];
        expect(query).to.contain(param);
    });

    it(@"the placement_id request param should contain the provided value otherwise", ^{
        NSString *placementId = @"PLACEMENT_ID";
        sut.placementId = placementId;

        NSURLRequest *URLRequest = [sut URLRequestForOffers];
        NSString *query = [URLRequest.URL query];
        NSString *param = [NSString stringWithFormat:@"placement_id=%@", placementId];
        expect(query).to.contain(param);
    });

});

SpecEnd

