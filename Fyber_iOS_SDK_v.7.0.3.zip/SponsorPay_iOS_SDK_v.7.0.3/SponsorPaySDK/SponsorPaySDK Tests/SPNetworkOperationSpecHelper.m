//
//  SPNetworkOperationSpecHelper.m
//  SponsorPaySDK
//
//  Created by Daniel Barden on 24/09/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPNetworkOperationSpecHelper.h"

#import <OHHTTPStubs/OHHTTPStubs.h>

@implementation SPNetworkOperationSpecHelper

+ (void)enableValidResponseNetworkStub
{
    [OHHTTPStubs stubRequestsPassingTest:^BOOL(NSURLRequest *request) {
        return YES; // Stub ALL requests without any condition
    } withStubResponse:^OHHTTPStubsResponse*(NSURLRequest *request) {
        // Stub all those requests with "Hello World!" string
        NSData* stubData = [@"Hello World!" dataUsingEncoding:NSUTF8StringEncoding];
        return [OHHTTPStubsResponse responseWithData:stubData statusCode:200 headers:nil];
    }];
}

+ (void)enableInvalidResponseNetworkStub
{
    [OHHTTPStubs stubRequestsPassingTest:^BOOL(NSURLRequest *request) {
        return YES; // Stub ALL requests without any condition
    } withStubResponse:^OHHTTPStubsResponse*(NSURLRequest *request) {
        return [OHHTTPStubsResponse responseWithError:[NSError errorWithDomain:NSURLErrorDomain
                                                                          code:kCFURLErrorNotConnectedToInternet
                                                                      userInfo:nil]];
    }];
}

+ (void)disableAllNetworkStubs
{
    [OHHTTPStubs removeAllStubs];
}
@end
