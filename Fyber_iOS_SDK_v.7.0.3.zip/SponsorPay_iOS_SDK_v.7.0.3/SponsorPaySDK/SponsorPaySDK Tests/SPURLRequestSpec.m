//
//  SPURLRequestSpec.m
//  SponsorPaySDK
//
//  Created by Piotr  on 18/07/14.
//  Copyright 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>
#import "SPUser.h"
#import "SPURLRequest.h"
#import "SponsorPaySDK.h"
#import <CoreLocation/CoreLocation.h>

SpecBegin(SPURLRequestSpec)

describe(@"SPURLRequest generation", ^{

    __block SPUser *user;
    __block NSDate *dob;

    beforeEach(^{
        // Initialize user
        SponsorPaySDK *sdk = [SponsorPaySDK instance];
        user = sdk.user;

    });

    it(@"Validate URL encoding of the request", ^{

        // Set some parameters
        NSString *expectedHeaderValue = @"MyKey1=MyValue%20WithSpace&MyKey2=MyValue%2BWithPlus";
        [user setCustomParameters:@{
                                    @"MyKey1" : @"MyValue WithSpace",
                                    @"MyKey2" : @"MyValue+WithPlus",
                                    }];
        NSURLRequest *request = [SPURLRequest requestWithUserDataForURL:[NSURL URLWithString:@"http://localhost"]];

        expect(request).notTo.beNil;

        NSString *headerValue = [request valueForHTTPHeaderField:SPUserHeaderKey];

        expect(headerValue).notTo.beNil;
        expect(headerValue).equal(expectedHeaderValue);
        
    });
    
    
    afterEach(^{
        dob = nil;
        user = nil;
    });
    
});



SpecEnd