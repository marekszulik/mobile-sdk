//
//  VCSVirtualCurrencyServerConnectorHelper.m
//  SponsorPaySDK
//
//  Created by Daniel Barden on 18/09/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPVirtualCurrencyServerConnectorHelper.h"
#import <OHHTTPStubs/OHHTTPStubs.h>
#import <OCMock/OCMock.h>

@implementation SPVirtualCurrencyServerConnectorHelper

static id validDeltaOfCoinsNetworkStub;

+ (void)enableValidDeltaOfCoinsNetworkStub
{
    [self validResponseWithSignature:@"78399c9d1ea3d060f5cdcc8effbc29e6da7c278e"];
}

+ (void)enableInvalidSignatureNetworkStub
{
    [self validResponseWithSignature:@"Invalid signature"];
}

+ (void)enableServerErrorNetworkStub
{
    // Mocks the network request
    validDeltaOfCoinsNetworkStub = [OHHTTPStubs stubRequestsPassingTest:^BOOL(NSURLRequest *request) {
        return [request.URL.host isEqualToString:@"api.sponsorpay.com"];
    } withStubResponse:^OHHTTPStubsResponse * (NSURLRequest * request) {
        return [OHHTTPStubsResponse
                responseWithFileAtPath:OHPathForFileInBundle(@"VCSResponseServerError.json", nil)
                statusCode:500
                headers:@{@"Content-Type": @"text/json"}];
    }];
}

+ (void)enableInvalidResponseNetworkStub
{
    // Mocks the network request
    validDeltaOfCoinsNetworkStub = [OHHTTPStubs stubRequestsPassingTest:^BOOL(NSURLRequest *request) {
        return [request.URL.host isEqualToString:@"api.sponsorpay.com"];
    } withStubResponse:^OHHTTPStubsResponse * (NSURLRequest * request) {
        return [OHHTTPStubsResponse
                responseWithFileAtPath:OHPathForFileInBundle(@"VCSResponseInvalid.json", nil)
                statusCode:200
                headers:@{
                          @"Content-Type": @"text/json",
                          @"X-Sponsorpay-Response-Signature": @"f54f516145aea6bf62098f175a00835ff8bb4daa"
                          }];
    }];
}

+ (void)disableLastNetworkStub
{
    [OHHTTPStubs removeLastStub];
}

+ (void)disableAllNetworkStubs
{
    [OHHTTPStubs removeAllStubs];
}

+ (void)mockNSDate
{
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setDay:10];
    [comps setMonth:9];
    [comps setYear:2014];

    id classMock = OCMClassMock([NSDate class]);

    OCMStub(ClassMethod([classMock dateWithTimeIntervalSinceNow:0])).andReturn([[NSCalendar currentCalendar] dateFromComponents:comps]);
}

#pragma mark - Helper methods

+ (void)validResponseWithSignature:(NSString *)signature
{
    // Mocks the network request
    validDeltaOfCoinsNetworkStub = [OHHTTPStubs stubRequestsPassingTest:^BOOL(NSURLRequest *request) {
        return [request.URL.host isEqualToString:@"api.sponsorpay.com"];
    } withStubResponse:^OHHTTPStubsResponse * (NSURLRequest * request) {
        return [OHHTTPStubsResponse
                responseWithFileAtPath:OHPathForFileInBundle(@"VCSResponseSuccessful.json", nil)
                statusCode:200
                headers:@{
                          @"Content-Type": @"text/json",
                          @"X-Sponsorpay-Response-Signature": signature
                          }];
    }];
}

@end
