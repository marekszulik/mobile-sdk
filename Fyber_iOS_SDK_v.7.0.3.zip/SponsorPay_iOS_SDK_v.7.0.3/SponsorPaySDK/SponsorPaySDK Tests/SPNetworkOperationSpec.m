//
//  SPNetworkOperationSpec.m
//  SponsorPayTestApp
//
//  Created by Piotr  on 26/06/14.
//  Copyright 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>

#import "SPNetworkOperation.h"
#import "SPNetworkOperationSpecHelper.h"

SpecBegin(SPNetworkOperation)

describe(@"SPNetworkOperation", ^{
    __block SPNetworkOperation *operation;
    __block NSURL *url;

    beforeAll(^{
        url = [NSURL URLWithString:@"http://sponsorpay.com"];
    });

    before(^{
        operation = [[SPNetworkOperation alloc] initWithUrl:url];
    });

    it(@"should call success block when operation is a success", ^AsyncBlock{
        [SPNetworkOperationSpecHelper enableValidResponseNetworkStub];
        operation.networkOperationSuccessBlock = ^(SPNetworkOperation *networkOperation){
            expect(networkOperation.response.statusCode).to.equal(200);
            [SPNetworkOperationSpecHelper disableAllNetworkStubs];
            done();
        };

        [operation start];
    });

    it(@"should call error block when operation fails", ^AsyncBlock{
        [SPNetworkOperationSpecHelper enableInvalidResponseNetworkStub];
        operation.networkOperationFailedBlock = ^(SPNetworkOperation *networkOperation, NSError *error){
            expect(error).toNot.beNil();
            done();
        };
        [operation start];
    });

    it(@"should not execute the completion block on the main thread", ^AsyncBlock{
        [SPNetworkOperationSpecHelper enableValidResponseNetworkStub];

        dispatch_queue_t queue = dispatch_queue_create("com.sponsorpay.SponsorPaySDK", NULL);
        operation.completionQueue = queue;
        operation.networkOperationSuccessBlock = ^(SPNetworkOperation *networkOperation){
            expect([NSThread isMainThread]).to.beFalsy();
            expect(networkOperation.response.statusCode).to.equal(200);
            [SPNetworkOperationSpecHelper disableAllNetworkStubs];
            dispatch_async(dispatch_get_main_queue(), ^{
                done();
            });
        };

        [operation start];

    });
});

SpecEnd
