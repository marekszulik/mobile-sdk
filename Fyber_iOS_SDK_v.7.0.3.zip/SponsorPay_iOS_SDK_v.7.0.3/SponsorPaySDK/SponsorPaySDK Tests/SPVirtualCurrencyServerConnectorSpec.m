//
//  SPVirtualCurrencyServerConnectorSpec.m
//  SponsorPaySDK
//
//  Created by Daniel Barden on 18/09/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>
#import <OCMock/OCMock.h>
#import <OHHttpStubs/OHHttpStubs.h>
#import <Aspects/Aspects.h>

#import "SPCredentials.h"
#import "SPVirtualCurrencyRequestErrorType.h"
#import "SPVirtualCurrencyServerConnector.h"
#import "SPVirtualCurrencyServerConnector_SDKPrivate.h"
#import "SPVirtualCurrencyServerConnector+SPTesting.h"
#import "SPVirtualCurrencyServerConnectorSpecDelegate.h"
#import "SPVirtualCurrencyServerConnectorHelper.h"
#import "SPVirtualCurrencyServerConnector+SPTesting.h"

SpecBegin(SPVirtualCurrencyServerConnector)

describe(@"SPVirtualCurrencyServerConnector", ^{
    __block SPVirtualCurrencyServerConnector *sut;
    __block SPVirtualCurrencyServerConnectorSpecDelegate *delegate;
    __block SPCredentials *credentials;


    beforeAll(^{
        // Mocks NSDate
        [SPVirtualCurrencyServerConnectorHelper mockNSDate];
    });

    before(^{
        delegate = [[SPVirtualCurrencyServerConnectorSpecDelegate alloc] init];
        sut = [[SPVirtualCurrencyServerConnector alloc] init];
        credentials = [SPCredentials credentialsWithAppId:@"1245" userId:@"test" securityToken:@"888"];

        sut.credentials = credentials;
        sut.delegate = delegate;
    });

    after(^{
        sut = nil;
    });

    afterAll(^{
        [SPVirtualCurrencyServerConnectorHelper disableAllNetworkStubs];
    });

    it(@"should return a valid delta of coins", ^{
        [SPVirtualCurrencyServerConnectorHelper enableValidDeltaOfCoinsNetworkStub];

        [sut fetchDeltaOfCoins];

        expect(delegate.vcs).will.equal(sut);
        expect(delegate.deltaOfCoins).will.equal(1);
        expect(delegate.currencyName).will.equal(@"bananas");

        [SPVirtualCurrencyServerConnectorHelper disableLastNetworkStub];
    });

    it(@"should return an overwritten currency name", ^{
        [SPVirtualCurrencyServerConnectorHelper enableValidDeltaOfCoinsNetworkStub];

        credentials.userConfig[SPVCSCurrencyName] = @"testCurrency";
        [sut fetchDeltaOfCoins];

        expect(delegate.vcs).will.equal(sut);
        expect(delegate.deltaOfCoins).will.equal(1);
        expect(delegate.currencyName).will.equal(@"testCurrency");

        [SPVirtualCurrencyServerConnectorHelper disableLastNetworkStub];
    });

    it(@"should trigger a notification", ^{
        [SPVirtualCurrencyServerConnectorHelper enableValidDeltaOfCoinsNetworkStub];

        expect(^{
            [sut fetchDeltaOfCoins];
        }).will.notify(SPVCSPayoffReceivedNotification);

        [SPVirtualCurrencyServerConnectorHelper disableLastNetworkStub];
    });

    it(@"should return an error when signature does no match", ^{
        [SPVirtualCurrencyServerConnectorHelper enableInvalidSignatureNetworkStub];

        credentials.userConfig[SPVCSCurrencyName] = @"testCurrency";
        [sut fetchDeltaOfCoins];

        expect(delegate.vcs).will.equal(sut);
        expect(delegate.currencyName).will.equal(nil);
        expect(delegate.errorType).will.equal(ERROR_INVALID_RESPONSE_SIGNATURE);

        [SPVirtualCurrencyServerConnectorHelper disableLastNetworkStub];

    });

    it(@"should return an error when server returns an error", ^{
        [SPVirtualCurrencyServerConnectorHelper enableServerErrorNetworkStub];

        credentials.userConfig[SPVCSCurrencyName] = @"testCurrency";

        [sut fetchDeltaOfCoins];

        expect(delegate.vcs).will.equal(sut);
        expect(delegate.currencyName).will.equal(nil);
        expect(delegate.errorType).will.equal(SERVER_RETURNED_ERROR);
        expect(delegate.errorCode).will.equal(@"500");

        [SPVirtualCurrencyServerConnectorHelper disableLastNetworkStub];
    });

    it(@"should return an error when malformed", ^{
        [SPVirtualCurrencyServerConnectorHelper enableInvalidResponseNetworkStub];
        [sut fetchDeltaOfCoins];

        expect(delegate.vcs).will.equal(sut);
        expect(delegate.errorType).will.equal(ERROR_INVALID_RESPONSE);
    });

    it(@"should trigger another request when default changes", ^{
        [SPVirtualCurrencyServerConnectorHelper enableValidDeltaOfCoinsNetworkStub];

        // Logs how many times the currency has been fetched
        __block NSInteger numCalls = 0;
        id<AspectToken> token = [sut aspect_hookSelector:@selector(fetchDeltaOfCoins) withOptions:AspectPositionAfter usingBlock:^{
            numCalls++;
        } error:nil];

        [sut setDefaultCurrencyId:@"testCurrency"];
        [sut fetchDeltaOfCoins];

        expect(numCalls).will.equal(2);
        expect(delegate.currencyName).will.equal(@"bananas");
        [token remove];
        [SPVirtualCurrencyServerConnectorHelper disableLastNetworkStub];
    });
});

SpecEnd
