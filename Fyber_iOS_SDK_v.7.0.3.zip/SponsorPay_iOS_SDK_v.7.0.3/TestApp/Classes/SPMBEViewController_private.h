//
//  SPMBEViewController+SPSettingsTableViewController.h
//  SponsorPayTestApp
//
//  Created by Pierre Bongen on 04.06.14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPMBEViewController.h"


@interface SPMBEViewController ()

@property (strong, nonatomic) SPBrandEngageClient *brandEngageClient;

@end
