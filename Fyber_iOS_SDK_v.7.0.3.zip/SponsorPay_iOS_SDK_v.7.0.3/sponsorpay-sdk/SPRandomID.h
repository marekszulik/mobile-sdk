//
//  SPRandomID.h
//  SponsorPay iOS SDK
//
//  Copyright 2011-2013 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SPRandomID : NSObject

+ (NSString *)randomIDString;

@end
