//
//  NSString+SPAdditions.h
//  SponsorPaySDK
//
//  Created by Titouan on 17/06/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (SPAdditions)

+ (BOOL)isStringEmpty:(NSString *)string;

@end