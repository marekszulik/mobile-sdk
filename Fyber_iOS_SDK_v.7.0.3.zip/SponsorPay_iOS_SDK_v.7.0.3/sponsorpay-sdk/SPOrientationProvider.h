//
//  SPOrientationProvider.h
//  SponsorPaySDK
//
//  Created by tito on 31/07/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPURLParametersProvider.h"

@interface SPOrientationProvider : NSObject<SPURLParametersProvider>

@end
