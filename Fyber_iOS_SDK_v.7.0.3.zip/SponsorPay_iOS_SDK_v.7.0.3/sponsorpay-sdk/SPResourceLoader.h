//
//  SPResourceLoader.h
//  SponsorPaySample
//
//  Created by David Davila on 7/30/13.
// Copyright 2011-2013 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface SPResourceLoader : NSObject

+ (UIImage *)imageWithName:(NSString *)name;

@end
