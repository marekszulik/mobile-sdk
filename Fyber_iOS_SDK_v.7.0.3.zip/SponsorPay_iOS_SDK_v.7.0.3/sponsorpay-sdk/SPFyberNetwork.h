//
//  SPFyberNetwork.m
//  NetworkAdapters
//
//  Created by tito on 17/07/14.
//  Copyright (c) 2014 sponsorpay. All rights reserved.
//

#import "SPBaseNetwork.h"

@interface SPFyberNetwork : SPBaseNetwork

@end
