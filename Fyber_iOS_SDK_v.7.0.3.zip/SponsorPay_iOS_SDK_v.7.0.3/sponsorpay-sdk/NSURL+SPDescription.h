//
//  NSURL+SPDescription.h
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 17/03/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURL (SPDescription)

- (NSString *)SPPrettyDescription;

@end
