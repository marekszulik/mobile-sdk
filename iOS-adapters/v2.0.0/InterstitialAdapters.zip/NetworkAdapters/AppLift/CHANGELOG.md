# Applift - adapter changelog

####2.2.0

- Supports Applift 4.1.0
- Removed support for iOS 5

####2.2.0

- Supports Applift 4.0.0

####2.1.0

- Supports Applift  3.0.6

####2.0.0

- Added interstitial mediation adapter