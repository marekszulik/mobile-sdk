# InMobi - adapter changelog

####2.0.2
 
 - Supports InMobi SDK 4.5.1
 - Minor changes

####2.0.0

- Added interstitial mediation adapter