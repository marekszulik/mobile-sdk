# Vungle - adapter changelog

####2.4.0

 - Added support for Vungle SDK 3.0.12
 - Added `SPVungleIncentivized`, `SPVungleIncentivizedAlertTitleText`, `SPVungleIncentivizedAlertBodyText`, `SPVungleIncentivizedAlertCloseButtonText` and `SPVungleIncentivizedAlertContinueButtonText` options to to the `.plist` file.

####2.3.1

 - Minor fixes

####2.3.0

 - Supports Vungle SDK 3.0.11
 - Removed `SPVungleShowClose`. Option handled by Vungle dashboard. 

####2.2.0

- Added support for Vungle SDK 3.0.10
- Removed legacy code.

####2.1.0

- Added support for Vungle SDK 3.0.9
- Added `SPVungleOrientation` and `SPVungleShowClose` options to to the `.plist` file.
 
####2.0.0

- Added rewarded video mediation adapter