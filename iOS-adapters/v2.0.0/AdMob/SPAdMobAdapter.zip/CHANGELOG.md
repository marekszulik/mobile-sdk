# AdMob - adapter changelog

####2.1.0

- Added Support for AdMob 7.0.0
- Removed `GAD_SIMULATOR_ID`. Option removed in AdMob SDK 7.0.0. 

####2.0.2
 
- Added Support for AdMob 6.12.2
- Minor changes

####2.0.1
 
- Minor changes

####2.0.0

- Added interstitial mediation adapter